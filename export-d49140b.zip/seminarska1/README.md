# Seminarska 1 pri MRO
Prva seminarska naloga pri predmetu Modeliranje racunalniskih omrezij, 3 letnik FRI (izdelana v skupini z [Tilen Venko](https://github.com/tvenko))

## Navodila
![Slika z navodili](navodila.png)
